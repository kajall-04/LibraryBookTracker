# Project Report — Library Book Tracker
**Course:** Object-Oriented Programming with Java (BYOP Capstone)
**Submitted by:** [Your Name]  
**Roll No.:** [Your Roll No.]  
**Date:** [Submission Date]

---

## 1. Problem Statement

Campus and small institutional libraries often rely on handwritten registers or basic spreadsheets to track books, borrowers, and return deadlines. This approach is error-prone, difficult to search, and provides no automated way to flag overdue books or calculate fines. The result is lost books, untracked dues, and a frustrating experience for both librarians and students.

**The Library Book Tracker** is a desktop application that digitises these core library operations — adding and removing books, issuing and returning them, searching the catalogue, and tracking overdue returns — within a clean, modern graphical interface.

---

## 2. Why This Problem Matters

- Every college campus has a library, yet many still rely on manual record-keeping.
- Overdue books block other students from accessing resources.
- There is no quick way to know at a glance how many books are available, who has which book, or who owes a fine.
- A lightweight desktop tool — requiring no internet, no server, no account — is ideal for small libraries.

This project solves a real, observable problem in an environment the developer interacts with daily.

---

## 3. Approach and Design

### 3.1 Architecture

The application follows a layered architecture aligned with OOP principles:

```
src/
 └── library/
      ├── model/        Book.java           (Data model)
      ├── service/      LibraryService.java (Business logic)
      └── ui/           MainWindow.java     (Swing GUI)
                        BookTableModel.java (MVC table model)
                        Theme.java          (Design constants)
                        RoundedPanel.java   (Custom component)
                        StyledButton.java   (Custom component)
```

| Layer   | Class(es)          | Responsibility                                        |
|---------|--------------------|-------------------------------------------------------|
| Model   | `Book`             | Encapsulates book data and state                      |
| Service | `LibraryService`   | All business logic: CRUD, issue/return, search, fine  |
| View    | `MainWindow` etc.  | Swing GUI, event handling, user feedback              |

### 3.2 Key Java Concepts Applied

| Concept                | Where Used                                                  |
|------------------------|-------------------------------------------------------------|
| **Classes & Objects**  | `Book` objects stored in `LibraryService`                   |
| **Encapsulation**      | Private fields with public getters/setters in `Book`        |
| **Collections**        | `LinkedHashMap<String, Book>` for ordered, fast lookup      |
| **Java Streams**       | Search, filter, and aggregate queries in `LibraryService`   |
| **Java Time API**      | `LocalDate`, `ChronoUnit` for due-date and overdue tracking |
| **Swing / MVC**        | `JTable` backed by `BookTableModel extends AbstractTableModel` |
| **Custom Painting**    | `RoundedPanel`, `StyledButton` override `paintComponent`    |
| **Event Handling**     | `ActionListener`, `MouseAdapter` for all user interactions  |
| **Switch Expressions** | `getValueAt()` in `BookTableModel` (Java 14+)               |

### 3.3 Features Implemented

1. **Add Book** — Enter title, author, and genre; a unique ID (B001, B002 …) is auto-assigned.
2. **Remove Book** — Remove any book that is currently not issued.
3. **Issue Book** — Select a book and enter a student name; due date is set 14 days from today automatically.
4. **Return Book** — Marks the book as returned; calculates and displays any overdue fine (₹5/day).
5. **Search** — Real-time filter across title, author, and genre simultaneously.
6. **Overdue List** — Dedicated dialog listing all overdue books with fine amounts.
7. **Stats Header** — Live counters for Total / Available / Issued / Overdue books.

---

## 4. Key Decisions

### Why `LinkedHashMap` instead of `ArrayList`?
Books need to be retrieved by ID in O(1) time (for issue/return operations). A `LinkedHashMap` preserves insertion order (so the table displays books in the order they were added) while still offering fast key-based lookup.

### Why no file persistence (by design)?
Persistence was intentionally left as a future enhancement to keep the scope of the BYOP manageable. The current in-memory model with seed data is sufficient to demonstrate all features and OOP concepts cleanly.

### Why Swing over JavaFX?
Swing is part of the standard JDK and requires no additional dependencies, making the project portable and easy to run on any machine with Java 8+.

### Fine Calculation
A flat rate of ₹5 per overdue day was chosen as a simple, realistic representation of actual library fine policies in many Indian colleges.

---

## 5. Challenges Faced

| Challenge | How It Was Resolved |
|-----------|---------------------|
| Making Swing look modern | Created `Theme.java` with a dark colour palette; wrote custom `paintComponent` overrides for buttons and panels with rounded corners |
| Keeping the table in sync | Implemented `BookTableModel extends AbstractTableModel` with `refresh()` and `setRows()` methods; calling these after every mutation keeps the view consistent with the model |
| Alternating row colours conflicting with the status column renderer | Applied a layered renderer strategy: the default renderer handles alternating rows, and the status column renderer is checked explicitly before applying row colour |
| Overdue calculation spanning dates | Used `ChronoUnit.DAYS.between(due, LocalDate.now())` which correctly handles month boundaries and leap years |

---

## 6. Learnings

- **Separation of concerns** is not just good practice — it makes the code dramatically easier to debug and extend. Having `LibraryService` completely independent of Swing meant I could test all the business logic without running the GUI.
- **`AbstractTableModel`** is far more powerful than `DefaultTableModel` because it lets you bind the table directly to your domain objects, avoiding duplication of data.
- **Java Streams** make collection queries expressive and concise — the 5-line search method in `LibraryService` would have been 20+ lines with traditional loops.
- Building with **custom Swing painting** taught me how the AWT paint pipeline works, including the importance of `setOpaque(false)` when doing custom background fills.

---

## 7. Future Enhancements

- **File / JSON persistence** — save and load the book catalogue across sessions.
- **Student management** — maintain a register of students with their borrowing history.
- **Export to CSV / PDF** — generate printable reports of issued or overdue books.
- **Multiple copy support** — track more than one physical copy of the same title.
- **Role-based login** — separate views for librarian (full access) and student (read-only search).

---

## 8. Conclusion

The Library Book Tracker successfully addresses a real problem observed in campus environments. It applies core Java and OOP concepts — encapsulation, collections, streams, the MVC pattern, and event-driven programming — in a purposeful, working application. The project demonstrates that a well-scoped, carefully executed solution can be both technically sound and genuinely useful without needing to be large in scale.
